<?php
require 'includes/config.php';
require 'smarty.php';
$templatefile = 'about';
require 'display.php';
