<?php
/* 
 * ShLink Script v2.0 By Mehdi Sadir 
 * #$Id: version.php 9666 2014-12-16
 * it contains the schema version ( datbase update version )
 * it contains the script current version
 */
$SCRIPT_VERSION = "2.0";
$SCRIPT_SCHEMA_VERSION = "2"; // don't change then name it used as variable in the install script
define('SCRIPT_VERSION', $SCRIPT_VERSION);
define('SCRIPT_SCHEMA_VERSION', $SCRIPT_SCHEMA_VERSION);

