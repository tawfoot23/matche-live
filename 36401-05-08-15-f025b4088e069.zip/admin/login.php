<?php
ob_start();
require '../includes/config.php';
require 'smarty.php';
if (isset($_COOKIE["username"])) {
    header("location: index.php");
}
// username and password sent from form
if (!empty($_POST['username']) && $_POST['password']) {
    $myusername = $_POST['username'];
    $mypassword = $_POST['password'];
     //Sanitize the query array to insert into database
    $myusername = SanitizeString($db->escape($myusername));
    $mypassword = SanitizeString($db->escape($mypassword));
    $table = 'admin';
    $db->where ('username', $myusername);
    $db->where ('password', sha1($mypassword));
    $results = $db->get($table , '2'); // 1 is number Of Rows optional
    $fetch   = $results[0];
    // If result matched $myusername and $mypassword, table row must be 1 row
    if($db->count == 1){
        setcookie("username",   $fetch['username']  , time()+3600 * 24 * 365); // for 1 year
        setcookie("name",       $fetch['name']      , time()+3600 * 24 * 365); // for 1 year
        setcookie("userid",     $fetch['id']        , time()+3600 * 24 * 365); // for 1 year
        setcookie("links",      $fetch['links']     , time()+3600 * 24 * 365); // for 1 year
        setcookie("admins",     $fetch['admins']    , time()+3600 * 24 * 365); // for 1 year
        setcookie("config",     $fetch['config']    , time()+3600 * 24 * 365); // for 1 year
        setcookie("ads",        $fetch['ads']       , time()+3600 * 24 * 365); // for 1 year
        header("location:index.php");
    } else {
        header("location:login_falid.php");
    }
}

// Smarty include html file
$smarty->assign ("is_demo", $is_demo);
$smarty->display("default/login.html");
ob_end_flush();
