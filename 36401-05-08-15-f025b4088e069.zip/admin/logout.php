<?php
// delete all path cookies
$past = time() - 3600;
foreach ( $_COOKIE as $key => $value )
{
    setcookie( $key, $value, $past);
}
// end delete all path cookies
require '../includes/config.php';
require 'smarty.php';
// check refere to protect admin from CSRF attacks
check_ref ($domain);
$templatefile = 'logout';
$smarty->display("default/logout.html");
