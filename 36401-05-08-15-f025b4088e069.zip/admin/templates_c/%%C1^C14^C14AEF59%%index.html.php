<?php /* Smarty version 2.6.19, created on 2015-07-23 16:32:34
         compiled from default/index.html */ ?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Dashboard <small>Statistics Overview</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Dashboard
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <?php if ($this->_tpl_vars['is_demo'] == 1): ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <i class="fa fa-info-circle"></i>  <strong>Like My Script?</strong> Buy it <a href="http://bit.ly/1vxTku0" class="alert-link">just $15</a> Very cheap!
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if ($this->_tpl_vars['install_exists'] == 1): ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <i class="fa fa-info-circle"></i>  Please delete the install folder or rename it
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-signal fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $this->_tpl_vars['alllinks']; ?>
</div>
                                        <div> Total links</div>
                                    </div>
                                </div>
                            </div>
                            <a href="viewlinks.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-globe fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $this->_tpl_vars['vistis']; ?>
</div>
                                        <div>Total visitors</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">All the time</span>
                                    <span class="pull-right"><i class="fa fa-thumbs-o-up"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-bullseye fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $this->_tpl_vars['online']; ?>
</div>
                                        <div>online now</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">right now</span>
                                    <span class="pull-right"><i class="fa fa-thumbs-o-up "></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-download fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $this->_tpl_vars['downloads']; ?>
</div>
                                        <div>Total downloads</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">Until now</span>
                                    <span class="pull-right"><i class="fa fa-thumbs-o-up"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-4">
                    </div>
                    <div class="row"></div>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="panel panel-yellow">
                                    <div class="panel-heading">
                                        <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Links download activities</h3>
                                    </div>
                                    <div class="panel-body">
                                        <div id="morris-donut-chart"></div>
                                        <div class="text-right">
                                            <a href="#">All The Time<i class="fa fa-thumbs-o-up" style="margin-left:5px"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <!-- Page Heading -->
                            <?php echo '    
                                <script type="text/javascript">
                                    Morris.Donut({
                                    element: \'morris-donut-chart\',
                                    data: [
                                    {label: "has downloaded", value: '; ?>
<?php echo $this->_tpl_vars['has_downloaded']; ?>
<?php echo '},
                                    {label: "never downloaded", value: '; ?>
<?php echo $this->_tpl_vars['never_downloads']; ?>
<?php echo ' },
                                    // {label: "visits", value: '; ?>
<?php echo $this->_tpl_vars['vistis']; ?>
<?php echo '}
                                    ]
                                    });   
                                </script>
                            '; ?>

                            <div class="col-lg-4">
                            <div class="panel panel-red">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Links added for the last 7 days</h3>
                                </div>
                                <div class="panel-body">
                                    <div id="morris-line-chart"></div>
                                    <div class="text-right">
                                        <a href="viewlinks.php">View Details <i class="fa fa-arrow-circle-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <?php echo '
                            <script>
                                // Line Chart
                                 Morris.Line({
                                // ID of the element in which to draw the chart.
                                element: \'morris-line-chart\',
                                // Chart data records -- each entry in this array corresponds to a point on
                                // the chart.
                                data: [{

                                    d: \''; ?>
<?php echo $this->_tpl_vars['date1']; ?>
<?php echo '\',
                                    links: '; ?>
<?php echo $this->_tpl_vars['count1']; ?>
<?php echo '
                                }, {
                                     d: \''; ?>
<?php echo $this->_tpl_vars['date2']; ?>
<?php echo '\',
                                    links: '; ?>
<?php echo $this->_tpl_vars['count2']; ?>
<?php echo '
                                }, {
                                     d: \''; ?>
<?php echo $this->_tpl_vars['date3']; ?>
<?php echo '\',
                                    links: '; ?>
<?php echo $this->_tpl_vars['count3']; ?>
<?php echo '
                                }, {
                                   d: \''; ?>
<?php echo $this->_tpl_vars['date4']; ?>
<?php echo '\',
                                    links: '; ?>
<?php echo $this->_tpl_vars['count4']; ?>
<?php echo '
                                }, {
                                   d: \''; ?>
<?php echo $this->_tpl_vars['date5']; ?>
<?php echo '\',
                                    links: '; ?>
<?php echo $this->_tpl_vars['count5']; ?>
<?php echo '
                                }, {
                                   d: \''; ?>
<?php echo $this->_tpl_vars['date6']; ?>
<?php echo '\',
                                    links: '; ?>
<?php echo $this->_tpl_vars['count6']; ?>
<?php echo '
                                }, {
                                  d: \''; ?>
<?php echo $this->_tpl_vars['date7']; ?>
<?php echo '\',
                                    links: '; ?>
<?php echo $this->_tpl_vars['count7']; ?>
<?php echo '
                                }, ],
                                // The name of the data record attribute that contains x-visitss.
                                xkey: \'d\',
                                // A list of names of data record attributes that contain y-visitss.
                                ykeys: [\'links\'],
                                // Labels for the ykeys -- will be displayed when you hover over the
                                // chart.
                                labels: [\'Links\'],
                                // Disables line smoothing
                                smooth: false,
                                resize: true
                                });
                            </script>
                            '; ?>


                            <div class="col-lg-4">
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> all time Statistics</h3>
                                    </div>
                                    <div class="panel-body">
                                        <div id="morris-bar-chart"></div>
                                        <div class="text-right">
                                            <a href="#">All The Time<i class="fa fa-thumbs-o-up"  style="margin-left:5px"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php echo '
                            <script>
                                var downloads = '; ?>
<?php echo $this->_tpl_vars['downloads']; ?>
<?php echo ';
                                var alllinks = '; ?>
<?php echo $this->_tpl_vars['alllinks']; ?>
<?php echo ';
                                var visits = '; ?>
<?php echo $this->_tpl_vars['vistis']; ?>
<?php echo ';
                                Morris.Bar({
                                element: \'morris-bar-chart\',
                                data: [{
                                    device: \'all downloads\',
                                    geekbench: downloads
                                }, {
                                    device: \'all vists\',
                                    geekbench: visits   
                                }, {
                                    device: \'All links\',
                                    geekbench: alllinks
                                }],
                                xkey: \'device\',
                                ykeys: [\'geekbench\'],
                                labels: [\'Total\'],
                                barRatio: 0.4,
                                xLabelAngle: 35,
                                hideHover: \'auto\',
                                resize: true
                                });                          
                                                                        
                            </script>
                            '; ?>

                                             
                                             

                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="panel panel-green">
                                    <div class="panel-heading">
                                        <h1 class="panel-title"><i class="fa fa-comments"></i> Something to remember </h1>
                                    </div>
                                     <?php if ($this->_tpl_vars['is_demo'] == 1): ?>
                                     <p class="bg-danger">In demo the form is disabled </p>
                                    <?php endif; ?>
                                    <div class="panel-body">
                                        <form action="index.php" method="post" name="notes">
                                        <div align="center">
                                            <textarea name="note"  rows="8" class="form-control"><?php echo $this->_tpl_vars['notes']; ?>
</textarea>
                                            <?php if ($this->_tpl_vars['done'] == 1): ?>
                                                <?php echo '
                                                    <script>
                                                        window.setTimeout(function () {
                                                         location.href = "index.php";
                                                        }, 2000)
                                                    </script>
                                                '; ?>

                                            <?php endif; ?>
                                        </div>
                                        <div align="center">
                                          
                                            <button type="submit" class="btn btn-success" name="action">Submit Button</button>
                                            <button type="reset" class="btn btn-warning">Reset Button</button>
                                            <input type="hidden" name="notes" value="1" />
                                              
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- /.row -->
                </div>
            <!-- /.container-fluid -->
            </div>
        <!-- /#page-wrapper -->


   