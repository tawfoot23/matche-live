<?php /* Smarty version 2.6.19, created on 2015-07-31 12:38:50
         compiled from default/viewlinks.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'truncate', 'default/viewlinks.html', 108, false),)), $this); ?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Manage links
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file"></i> Manage links
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <?php if ($this->_tpl_vars['action'] == 'del'): ?>
                <div class="alert alert-success">
                    <strong> successfully removed</strong> you will be redirected now 
                </div>
                <?php echo '
                <script>
                   window.setTimeout(function () {
                      location.href = "viewlinks.php";
                   }, 2000)
                </script>
                '; ?>

                <?php elseif ($this->_tpl_vars['action'] == 'update'): ?>
                <?php if ($this->_tpl_vars['done'] == 0): ?>
                <div class="col-lg-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                           Use this form to  edit a link
                        </div>
                        <div class="panel-body">
                            <form role="form" action="viewlinks.php?do=update&id=<?php echo $this->_tpl_vars['id']; ?>
" name="formurl" method=post >
                                <input type="hidden" name="form_action" value="1">
                                <div class="form-group">
                                    <label class="text-primary">URL name</label>
                                    <input class="form-control" name="name" value="<?php echo $this->_tpl_vars['name']; ?>
">
                                </div>
                                <div class="form-group">
                                    <label class="text-primary">URL</label>
                                    <input class="form-control" name="url" value="<?php echo $this->_tpl_vars['url']; ?>
">
                                </div>
                                <div class="form-group">
                                    <label class="text-primary">The size</label>
                                    <input class="form-control" name="size" value="<?php echo $this->_tpl_vars['size']; ?>
">
                                </div>
                                <div class="form-group">
                                    <label class="text-primary">the owner</label>
                                    <input class="form-control" name="author" value="<?php echo $this->_tpl_vars['author']; ?>
">
                                </div>
                                <button type="submit" class="btn btn-success" name="action">edit the link</button>
                            </form>
                        </div>
                        <div class="panel-footer">
                            edit a link
                        </div>
                    </div>
                </div>
                <?php elseif ($this->_tpl_vars['done'] == 1): ?>
                <div class="alert alert-success">
                    <strong> successully edited</strong> you will be redirected now 
                </div>
                <?php echo '
                <script>
                   window.setTimeout(function () {
                      location.href = "viewlinks.php";
                    }, 2000)
                </script>
                '; ?>

                <?php endif; ?>
                <?php else: ?>
		<form action="viewlinks.php?do=del" method="post" name="urls">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2>Edit links</h2>
                            <?php if ($this->_tpl_vars['is_demo'] == 1): ?>
                            <p class="bg-danger">In demo the form  is disabled </p>
                            <?php endif; ?>                            
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr class="success">
                                            <th><input type="checkbox" name="check_all" value="" onclick="checkAll(this.form)" class="checkbox" /></th>
                                            <th>name</th>
                                            <th>URL</th>
                                            <th>file size</th>
                                            <th>owner</th>
                                            <th>date added</th>
                                            <th>added by</th>
											<th>Downloads</th>
											<th>preview</th>
                                            <th>edit</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php unset($this->_sections['id']);
$this->_sections['id']['name'] = 'id';
$this->_sections['id']['loop'] = is_array($_loop=$this->_tpl_vars['urls']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['id']['show'] = true;
$this->_sections['id']['max'] = $this->_sections['id']['loop'];
$this->_sections['id']['step'] = 1;
$this->_sections['id']['start'] = $this->_sections['id']['step'] > 0 ? 0 : $this->_sections['id']['loop']-1;
if ($this->_sections['id']['show']) {
    $this->_sections['id']['total'] = $this->_sections['id']['loop'];
    if ($this->_sections['id']['total'] == 0)
        $this->_sections['id']['show'] = false;
} else
    $this->_sections['id']['total'] = 0;
if ($this->_sections['id']['show']):

            for ($this->_sections['id']['index'] = $this->_sections['id']['start'], $this->_sections['id']['iteration'] = 1;
                 $this->_sections['id']['iteration'] <= $this->_sections['id']['total'];
                 $this->_sections['id']['index'] += $this->_sections['id']['step'], $this->_sections['id']['iteration']++):
$this->_sections['id']['rownum'] = $this->_sections['id']['iteration'];
$this->_sections['id']['index_prev'] = $this->_sections['id']['index'] - $this->_sections['id']['step'];
$this->_sections['id']['index_next'] = $this->_sections['id']['index'] + $this->_sections['id']['step'];
$this->_sections['id']['first']      = ($this->_sections['id']['iteration'] == 1);
$this->_sections['id']['last']       = ($this->_sections['id']['iteration'] == $this->_sections['id']['total']);
?>
                                        <tr>
                                            <td class="active"><input name="check[]" type="checkbox" value="<?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['id']; ?>
"  /> </td>
                                            <?php if ($this->_tpl_vars['urls'][$this->_sections['id']['index']]['name'] == ''): ?>
                                            <td>N/A</td>
                                            <?php else: ?>
                                               <td><?php echo ((is_array($_tmp=$this->_tpl_vars['urls'][$this->_sections['id']['index']]['name'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 40, "---") : smarty_modifier_truncate($_tmp, 40, "---")); ?>
</td>
                                            <?php endif; ?>
                                            <td><a href="<?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['url']; ?>
" target="_blank"><?php echo ((is_array($_tmp=$this->_tpl_vars['urls'][$this->_sections['id']['index']]['url'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 40, "---") : smarty_modifier_truncate($_tmp, 40, "---")); ?>
</a></td>
                                            <?php if ($this->_tpl_vars['urls'][$this->_sections['id']['index']]['size'] == '0'): ?>
                                            <td>N/A</td>
                                            <?php else: ?>
                                               <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['size']; ?>
</td>
                                            <?php endif; ?>
                                            <?php if ($this->_tpl_vars['urls'][$this->_sections['id']['index']]['author'] == ''): ?>
                                            <td>N/A</td>
                                            <?php else: ?>
                                               <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['author']; ?>
</td>
                                            <?php endif; ?>
                                            <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['date']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['admin']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['downloads']; ?>
</td>
                                            <td><a href="<?php echo $this->_tpl_vars['siteurl']; ?>
/<?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['id']; ?>
" target="_blank" >preview</a></td>
                                            <td><a href="viewlinks.php?do=update&id=<?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['id']; ?>
"><button type="button" class="btn btn-primary">edit it</button></a></td>
                                        </tr>
                                    <?php endfor; endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <p>
                        <input type="hidden" name="page_num" value="<?php echo $this->_tpl_vars['page_num']; ?>
" />
                        <input name="Submit" class="btn btn-danger" type="submit" value="remove" onclick="alert4d(this.form,'soory you didn't select the link please select one !')" />
                    </p>
		</form>		 
                <?php echo $this->_tpl_vars['pagination']; ?>

                <?php endif; ?>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->


   