<?php /* Smarty version 2.6.19, created on 2015-08-04 16:59:46
         compiled from default/config.html */ ?>
<div id="page-wrapper">
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Manage site settings
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file"></i> site settings
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <?php if ($this->_tpl_vars['done'] == 0): ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="panel panel-success">
                                    <?php if ($this->_tpl_vars['is_demo'] == 1): ?>
                                        <p class="bg-danger">In demo editing settings are disabled </p>
                                                <?php endif; ?>
                                    <div class="panel-heading">
                                        Use this form to  manage settings
                                    </div>
                                    <div class="panel-body">
                                        <form role="form" action="config.php" name="formurl" method="post">
                                            <input type="hidden" name="form_action" value="1">
                                            <div class="form-group">
                                                <label class="text-primary">site's name</label>
                                                <input class="form-control" name="sitename" value="<?php echo $this->_tpl_vars['sitename']; ?>
">
                                            </div>
                                            <div class="form-group">
                                                <label class="text-primary">site's URL</label>
                                                <input class="form-control" name="siteurl" value="<?php echo $this->_tpl_vars['siteurl']; ?>
" required>
                                            </div>
                                            <div class="form-group">
                                                <label class="text-primary">Site's title</label>
                                                <input class="form-control" name="sitetitle" value="<?php echo $this->_tpl_vars['sitetitle']; ?>
">
                                             </div>
                                            <div class="form-group">
                                                    <label class="text-primary">email</label>
                                                    <input class="form-control" name="email" value="<?php echo $this->_tpl_vars['email']; ?>
">
                                            </div>
                                            <div class="form-group">
                                                <label class="radio">template</label>
                                                <select size="1" name="template">
                                                    <option selected value="<?php echo $this->_tpl_vars['template']; ?>
"><?php echo $this->_tpl_vars['template']; ?>
</option>
                                                    <?php unset($this->_sections['files']);
$this->_sections['files']['name'] = 'files';
$this->_sections['files']['loop'] = is_array($_loop=$this->_tpl_vars['templates']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['files']['show'] = true;
$this->_sections['files']['max'] = $this->_sections['files']['loop'];
$this->_sections['files']['step'] = 1;
$this->_sections['files']['start'] = $this->_sections['files']['step'] > 0 ? 0 : $this->_sections['files']['loop']-1;
if ($this->_sections['files']['show']) {
    $this->_sections['files']['total'] = $this->_sections['files']['loop'];
    if ($this->_sections['files']['total'] == 0)
        $this->_sections['files']['show'] = false;
} else
    $this->_sections['files']['total'] = 0;
if ($this->_sections['files']['show']):

            for ($this->_sections['files']['index'] = $this->_sections['files']['start'], $this->_sections['files']['iteration'] = 1;
                 $this->_sections['files']['iteration'] <= $this->_sections['files']['total'];
                 $this->_sections['files']['index'] += $this->_sections['files']['step'], $this->_sections['files']['iteration']++):
$this->_sections['files']['rownum'] = $this->_sections['files']['iteration'];
$this->_sections['files']['index_prev'] = $this->_sections['files']['index'] - $this->_sections['files']['step'];
$this->_sections['files']['index_next'] = $this->_sections['files']['index'] + $this->_sections['files']['step'];
$this->_sections['files']['first']      = ($this->_sections['files']['iteration'] == 1);
$this->_sections['files']['last']       = ($this->_sections['files']['iteration'] == $this->_sections['files']['total']);
?>
                                                    <option value="<?php echo $this->_tpl_vars['templates'][$this->_sections['files']['index']]; ?>
"><?php echo $this->_tpl_vars['templates'][$this->_sections['files']['index']]; ?>
</option>
                                                    <?php endfor; endif; ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label class="text-primary">number of seconds to wait</label>
                                                <input class="form-control" name="time" value="<?php echo $this->_tpl_vars['time']; ?>
">
                                            </div>
                                            <div class="form-group">
                                                <label class="text-primary">keywords</label>
                                                <textarea  rows="5" class="form-control" name="keywords" value="<?php echo $this->_tpl_vars['keywords']; ?>
"><?php echo $this->_tpl_vars['keywords']; ?>
</textarea>
                                            </div>
                                            <div class="form-group">
                                                <label class="text-primary">description</label>
                                                <textarea  rows="5" class="form-control" name="description" value="<?php echo $this->_tpl_vars['description']; ?>
"><?php echo $this->_tpl_vars['description']; ?>
</textarea>
                                            </div>
                                            <div class="form-group padding_left_15" >
                                                <label class="radio">open link in Popup </label>
                                                <label class="radio-inline">
                                                    <input type="radio"  class="radio" value="0" name="link_window" <?php if ($this->_tpl_vars['link_window'] == 0): ?>checked<?php else: ?><?php endif; ?> >
                                                    disable
                                                </label>
                                                <label class="radio-inline">
                                                    <input type="radio" class="radio" name="link_window" <?php if ($this->_tpl_vars['link_window'] == 1): ?>checked<?php else: ?><?php endif; ?> value="1">
                                                    enable
                                                </label>   
                                            </div>
                                            <div class="form-group padding_left_15" >
                                                <label class="radio">Adsense Revenue Sharing </label>
                                                <label class="radio-inline">
                                                    <input type="radio"  class="radio" value="0" name="second_page" <?php if ($this->_tpl_vars['second_page'] == 0): ?>checked<?php else: ?><?php endif; ?> >
                                                    disable
                                                </label>
                                                <label class="radio-inline">
                                                    <input type="radio" class="radio" name="second_page" <?php if ($this->_tpl_vars['second_page'] == 1): ?>checked<?php else: ?><?php endif; ?> value="1">
                                                    enable
                                                </label>   
                                            </div>
                                            <div class="form-group padding_left_15" >
                                                <label class="radio">site status </label>
                                                <label class="radio-inline">
                                                    <input type="radio"  class="radio" value="0" name="sitestate" <?php if ($this->_tpl_vars['sitestate'] == 0): ?>checked<?php else: ?><?php endif; ?> >
                                                    closed
                                                </label>
                                                <label class="radio-inline">
                                                    <input type="radio" class="radio" name="sitestate" <?php if ($this->_tpl_vars['sitestate'] == 1): ?>checked<?php else: ?><?php endif; ?> value="1">
                                                    Open
                                                </label>   
                                            </div>
                                            <div class="form-group">
                                                <label class="text-primary">closed message</label>
                                                <textarea  rows="5" class="form-control" name="sitestatemsg" value="<?php echo $this->_tpl_vars['time']; ?>
"><?php echo $this->_tpl_vars['sitestatemsg']; ?>
</textarea>
                                            </div>
                                            <div class="form-group">
                                                <label class="text-primary">analytics</label>
                                                <textarea  rows="5" class="form-control" name="analytics" value="<?php echo $this->_tpl_vars['time']; ?>
"><?php echo $this->_tpl_vars['analytics']; ?>
</textarea>
                                            </div>
                                           
                                            <button type="submit" class="btn btn-success" name="action">edit settings</button>
                                           
                                        </form>
                                    </div>
                                    <div class="panel-footer">
                                        edit settings
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php elseif ($this->_tpl_vars['done'] == 1): ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <h1>successfully edited settings</h1>
                                    <div class="form-group has-success">
                                        <div class="alert alert-success">
                                            <strong> successfully edited</strong> you will be redirected now 
                                        </div>
                                        <?php echo '
                                            <script>
                                            window.setTimeout(function () {
                                            location.href = "config.php";
                                            }, 2000)
                                            </script>
                                        '; ?>

                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->