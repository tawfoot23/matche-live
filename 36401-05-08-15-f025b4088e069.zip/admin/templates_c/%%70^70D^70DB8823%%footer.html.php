<?php /* Smarty version 2.6.19, created on 2015-07-23 16:32:34
         compiled from default/footer.html */ ?>
    </div>
 <!-- /#wrapper -->
</body>
</html>