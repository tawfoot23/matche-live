<?php /* Smarty version 2.6.19, created on 2015-07-23 16:58:17
         compiled from default/viewads.html */ ?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Manage Ads
                            <small>set options</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file"></i> Manage Ads
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                         <?php if ($this->_tpl_vars['action'] == 'delads'): ?>

                        <table width="777" cellpadding="0" cellspacing="0"><tr><td width="777" height="25">
                            <table width="777" cellpadding="0" cellspacing="0"><tr><td width="25"><img src="./templates/default/images/container2_right.gif"></td><td background="./templates/default/images/container2_slice.gif" style="padding-right:10px;color:white;">remove group of links</td><td width="25"><img src="./templates/default/images/container2_left.gif"></td></tr></table></td></tr><tr><td width="777">
                            <table width="777" cellpadding="0" cellspacing="0"><tr><td width="1" bgcolor="#d8d8d8"><img src="./templates/default/images/spacer.gif" width=1 height=1></td>
                                <td width="775" style="padding:20px;" valign="top"><h1>removing process successfully completed</h1>
                            </table>
                        </table>
                        <table>
                            <tr>
                                <td align="center">removing process successfully completed you will be redirected soon ...
                                </td>
                                <?php echo '
                                <script>
                                   window.setTimeout(function () {
                                      location.href = "viewads.php";
                                   }, 2000)
                                </script>
                                '; ?>

                            </tr>
                        </table>
                        <?php elseif ($this->_tpl_vars['action'] == 'updateads'): ?>
                        <?php if ($this->_tpl_vars['done'] == 0): ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="panel panel-success">
                                    <div class="panel-heading">
                                       Use this form to  manage the ad
                                    </div>
                                    <?php if ($this->_tpl_vars['is_demo'] == 1): ?>
                                    <p class="bg-danger">In demo the form  is disabled </p>
                                    <?php endif; ?>
                                    <div class="panel-body">
                                    <form role="form" action="viewads.php?do=update&id=<?php echo $this->_tpl_vars['adsid']; ?>
&form=1" method="post">
                                        <input type="hidden" name="form_action" value="1">
                                        <div class="form-group">
                                            <label class="text-primary">
                                                the name of the ad:
                                            </label>
                                            <input class="form-control" name="sitename" value="<?php echo $this->_tpl_vars['sitename']; ?>
">
                                        </div>
                                        <div class="form-group padding_left_15" >
                                            <label class="text-primary">
                                                ad status 
                                            </label>
                                            <label class="radio">
                                                <input name="active" type="radio" <?php if ($this->_tpl_vars['active'] == 1): ?>checked<?php else: ?><?php endif; ?> value="1" />
                                                enable
                                            </label>
                                            <label class="radio">
                                                <input name="active" type="radio" <?php if ($this->_tpl_vars['active'] == 2): ?>checked<?php else: ?><?php endif; ?> value="2" />
                                                disable
                                            </label>   
                                        </div>
                                        <div class="form-group">
                                            <label class="radio">
                                                used template
                                            </label>
                                            <select size="1" name="template">
                                                <option selected value="<?php echo $this->_tpl_vars['template']; ?>
">
                                                    <?php echo $this->_tpl_vars['template']; ?>

                                                </option>
                                                <?php unset($this->_sections['files']);
$this->_sections['files']['name'] = 'files';
$this->_sections['files']['loop'] = is_array($_loop=$this->_tpl_vars['templates']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['files']['show'] = true;
$this->_sections['files']['max'] = $this->_sections['files']['loop'];
$this->_sections['files']['step'] = 1;
$this->_sections['files']['start'] = $this->_sections['files']['step'] > 0 ? 0 : $this->_sections['files']['loop']-1;
if ($this->_sections['files']['show']) {
    $this->_sections['files']['total'] = $this->_sections['files']['loop'];
    if ($this->_sections['files']['total'] == 0)
        $this->_sections['files']['show'] = false;
} else
    $this->_sections['files']['total'] = 0;
if ($this->_sections['files']['show']):

            for ($this->_sections['files']['index'] = $this->_sections['files']['start'], $this->_sections['files']['iteration'] = 1;
                 $this->_sections['files']['iteration'] <= $this->_sections['files']['total'];
                 $this->_sections['files']['index'] += $this->_sections['files']['step'], $this->_sections['files']['iteration']++):
$this->_sections['files']['rownum'] = $this->_sections['files']['iteration'];
$this->_sections['files']['index_prev'] = $this->_sections['files']['index'] - $this->_sections['files']['step'];
$this->_sections['files']['index_next'] = $this->_sections['files']['index'] + $this->_sections['files']['step'];
$this->_sections['files']['first']      = ($this->_sections['files']['iteration'] == 1);
$this->_sections['files']['last']       = ($this->_sections['files']['iteration'] == $this->_sections['files']['total']);
?>
                                                    <option value="<?php echo $this->_tpl_vars['templates'][$this->_sections['files']['index']]; ?>
"><?php echo $this->_tpl_vars['templates'][$this->_sections['files']['index']]; ?>
</option>
                                                <?php endfor; endif; ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="text-primary">Ad code</label>
                                            <textarea  rows="5" class="form-control" name="code"><?php echo $this->_tpl_vars['code']; ?>
</textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="action">edit</button>
                                    </form>
                                </div>
                            <div class="panel-footer">
                                edit ad
                            </div>
                        </div>
                    </div>
                </div>
                <?php elseif ($this->_tpl_vars['done'] == 1): ?>
                <div class="alert alert-success">
                   <strong> successfully edited</strong> you will be redirected now 
                </div>
                <?php echo '
                <script>
                    window.setTimeout(function () {
                       location.href = "viewads.php";
                    }, 2000)
                </script>
                '; ?>

                <?php endif; ?>
                <?php else: ?>
                
                <form action="viewadmins.php?do=del" method="post" name="urls">
                    <div class="row">
                        <div class="col-lg-8">
                            <?php if ($this->_tpl_vars['is_demo'] == 1): ?>
                                <p class="bg-danger">In demo the form is disabled </p>
                            <?php endif; ?>
                            <h2>Edit Ads</h2>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr class="success">
                                            <th>publisher's name</th>
                                            <th>preview ad</th>
                                            <th>used templete</th>
                                            <th>active</th>
                                            <th>added by</th>
                                            <th>edit</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php unset($this->_sections['id']);
$this->_sections['id']['name'] = 'id';
$this->_sections['id']['loop'] = is_array($_loop=$this->_tpl_vars['urls']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['id']['show'] = true;
$this->_sections['id']['max'] = $this->_sections['id']['loop'];
$this->_sections['id']['step'] = 1;
$this->_sections['id']['start'] = $this->_sections['id']['step'] > 0 ? 0 : $this->_sections['id']['loop']-1;
if ($this->_sections['id']['show']) {
    $this->_sections['id']['total'] = $this->_sections['id']['loop'];
    if ($this->_sections['id']['total'] == 0)
        $this->_sections['id']['show'] = false;
} else
    $this->_sections['id']['total'] = 0;
if ($this->_sections['id']['show']):

            for ($this->_sections['id']['index'] = $this->_sections['id']['start'], $this->_sections['id']['iteration'] = 1;
                 $this->_sections['id']['iteration'] <= $this->_sections['id']['total'];
                 $this->_sections['id']['index'] += $this->_sections['id']['step'], $this->_sections['id']['iteration']++):
$this->_sections['id']['rownum'] = $this->_sections['id']['iteration'];
$this->_sections['id']['index_prev'] = $this->_sections['id']['index'] - $this->_sections['id']['step'];
$this->_sections['id']['index_next'] = $this->_sections['id']['index'] + $this->_sections['id']['step'];
$this->_sections['id']['first']      = ($this->_sections['id']['iteration'] == 1);
$this->_sections['id']['last']       = ($this->_sections['id']['iteration'] == $this->_sections['id']['total']);
?>
                                        <tr>
                                            <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['name']; ?>
</td>
                                            <td><a  style="cursor:pointer;" href"#" onclick="NewWindow('showads.php?id=<?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['id']; ?>
','name','500','500','yes');return false">click her to view</a></td>
                                            <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['template']; ?>
</td>
                                            <td>
                                                <?php if ($this->_tpl_vars['urls'][$this->_sections['id']['index']]['active'] == '1'): ?>
                                                    YES
                                                <?php else: ?>
                                                    NO
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['admin']; ?>

                                            </td>
                                            <td>
                                                <a href="viewads.php?do=update&id=<?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['id']; ?>
">
                                                <button type="button" class="btn btn-primary">edit it</button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endfor; endif; ?>   
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </form>	
                <?php endif; ?>
                </div>
            </div>
         <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
        <!-- /#page-wrapper -->


   