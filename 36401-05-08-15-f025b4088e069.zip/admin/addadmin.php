<?php
if (isset($_COOKIE["admins"]) && $_COOKIE["admins"]!= 1 ) {
    header("location: index.php");
}
require 'global.php';
require '../includes/config.php';
require 'smarty.php';
// check refere to protect admin from CSRF attacks
check_ref ($domain);
if (!empty($_POST['form_action']) 
        && $_POST['form_action'] == 1 
        && !empty($_POST['name']) 
        && !empty($_POST['password'])) {
    $name       = $_POST['name'];
    $realname   = $_POST['realname'];
    $email      = $_POST['email'];
    $password   = sha1($_POST['password']);
    $links      = (!empty($_POST['links']))  ? '1' : '0';
    $config     = (!empty($_POST['config'])) ? '1' : '0';
    $ads        = (!empty($_POST['ads']))    ? '1' : '0';
    $admin      = (!empty($_POST['admins']))  ? '1' : '0';
    //clean entries
    $name       = SanitizeString($db->escape($name));
    $realname   = SanitizeString($db->escape($realname));
    $email      = SanitizeString($db->escape($email));
    $password   = SanitizeString($db->escape($password));
    $links      = SanitizeString($db->escape($links));
    $config     = SanitizeString($db->escape($config));
    $ads        = SanitizeString($db->escape($ads));
    $admin      = SanitizeString($db->escape($admin));
    if ($is_demo !== "1") {
        $query      = "insert into `admin` ( `username` ,`name`,`email`,`password`,`links`,`config`,`ads`,`admins`) values ('$name','$realname','$email','$password','$links','$config','$ads','$admin')";
        $db->rawQuery($query);  
    }

    $smarty->assign ("done", 1);
} else {
    $smarty->assign ("done", 0);
}
$smarty->assign ("is_demo", $is_demo);
$templatefile = 'addadmin';
require 'display.php';
