<?php
if(!isset($_COOKIE["username"])){
    header("location: login.php");
}
