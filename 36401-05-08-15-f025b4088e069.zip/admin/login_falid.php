<?php
if (!isset($_COOKIE["username"])) {
    require '../includes/config.php';
    require 'smarty.php';
    $smarty->display("default/login_falid.html");
} else {
    header("location:index.php");
}
