<?php /* Smarty version 2.6.19, created on 2015-07-23 21:36:01
         compiled from default/index.html */ ?>
    <!-- Header -->
   <header>
        <div class="container">
<script type="text/javascript">
    google_ad_client = "ca-pub-8499374132228990";
    google_ad_slot = "4196565261";
    google_ad_width = 728;
    google_ad_height = 90;
</script>
<!-- adsea -->
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
            <div class="row">
                <div class="col-lg-12">
            <div class="row">
<!-- space 1 ---->	
<div class="col-sm-4 portfolio-item">
			<!--start add link  -->
		<div class="login">
		<form action="done.php" method="post">
				<input name="form_action" value="1" type="hidden">
				<input type="text" placeholder="File Name " name="name" required="required"><br>
				<input type="text" placeholder="http://www.exmple.com/?page=home " name="url" required pattern="https?://.+" x-moz-errormessage="Please match the requested format ( http:// )"><br>
				<input type="text" placeholder="File Size" name="size" ><br>
				<input type="text" placeholder="pub-00000000000000000 " name="author" required="required"><br>
				<input name="action" type="submit" value='Create Link' >
		</form>
		</div><!--end add link  -->
</div><div class="col-sm-1 portfolio-item"></div>
<!-- space 2 ----><div class="col-sm-4 portfolio-item" ><img src="templates/default/img/ex.gif" style="width:500px;height:258px"></div>


            </div>
                </div>
            </div>
        </div>
    </header>




  </div>


</div>
<div class="cboth"></div></div>  