<?php /* Smarty version 2.6.19, created on 2015-07-24 02:37:14
         compiled from default/multiadd.html */ ?>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php if ($this->_tpl_vars['done'] == 0): ?>
                    <div class="WideContentText">
                        <H2>Get Short &amp; Protected multi Links:</H2>
                        <br>
                        <FORM action="multi.php" method="post">
                            <input type="hidden" name="form_action" value="1">
                            <div align="center">
                                <textarea rows="14" name="multiurls"  class="input"  cols="59" required></textarea>
                            </div>
                            <p align="center">
                            <input type="submit" value="Make them Short!" name="send" class="btn btn-lg btn-outline"></p>
                        </FORM>
                    </div>
                    <div class="WideBottom">
                    </div>
                </div>

                <div class="clear">
                </div>
            </div>
            <?php elseif ($this->_tpl_vars['done'] == 1): ?>
                <div class="WideContentText">
                    <h6>Thank You ,, Now Have Fun <strong style="font-size: 30px">&#9786;</strong>  </h6> 
                    <br>
                    <div align="center">
<textarea  class="input" rows="14" name="multi" cols="59">
<?php unset($this->_sections['id']);
$this->_sections['id']['name'] = 'id';
$this->_sections['id']['loop'] = is_array($_loop=$this->_tpl_vars['links']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['id']['show'] = true;
$this->_sections['id']['max'] = $this->_sections['id']['loop'];
$this->_sections['id']['step'] = 1;
$this->_sections['id']['start'] = $this->_sections['id']['step'] > 0 ? 0 : $this->_sections['id']['loop']-1;
if ($this->_sections['id']['show']) {
    $this->_sections['id']['total'] = $this->_sections['id']['loop'];
    if ($this->_sections['id']['total'] == 0)
        $this->_sections['id']['show'] = false;
} else
    $this->_sections['id']['total'] = 0;
if ($this->_sections['id']['show']):

            for ($this->_sections['id']['index'] = $this->_sections['id']['start'], $this->_sections['id']['iteration'] = 1;
                 $this->_sections['id']['iteration'] <= $this->_sections['id']['total'];
                 $this->_sections['id']['index'] += $this->_sections['id']['step'], $this->_sections['id']['iteration']++):
$this->_sections['id']['rownum'] = $this->_sections['id']['iteration'];
$this->_sections['id']['index_prev'] = $this->_sections['id']['index'] - $this->_sections['id']['step'];
$this->_sections['id']['index_next'] = $this->_sections['id']['index'] + $this->_sections['id']['step'];
$this->_sections['id']['first']      = ($this->_sections['id']['iteration'] == 1);
$this->_sections['id']['last']       = ($this->_sections['id']['iteration'] == $this->_sections['id']['total']);
?>
<?php echo $this->_tpl_vars['siteurl']; ?>
/<?php echo $this->_tpl_vars['links'][$this->_sections['id']['index']]; ?>

<?php endfor; endif; ?>
</textarea>
                    </div>
                </div>
            <br>
            <div class="WideBottom">
            </div>
        </div>
        <div class="clear">
        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

   