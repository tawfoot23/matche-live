<?php /* Smarty version 2.6.19, created on 2015-07-24 02:37:04
         compiled from default/search.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'truncate', 'default/search.html', 38, false),)), $this); ?>
<section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h1>Search</h1>
                    <hr class="star-primary">
                </div>
            </div>

                <div class="row">
                    <div class="col-lg-12">
			<?php if ($this->_tpl_vars['done'] == 1): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <h4>Search results</h4>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover">
                                        <thead>
                                            <tr class="success">
                                                <th>name</th>
                                                <th>URL</th>
                                                <th>file size</th>
                                                <th>owner</th>
                                                <th>date added</th>
                                                <th>added by</th>
                                                <th>Downloads</th>
                                                 <th>preview</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php unset($this->_sections['id']);
$this->_sections['id']['name'] = 'id';
$this->_sections['id']['loop'] = is_array($_loop=$this->_tpl_vars['urls']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['id']['show'] = true;
$this->_sections['id']['max'] = $this->_sections['id']['loop'];
$this->_sections['id']['step'] = 1;
$this->_sections['id']['start'] = $this->_sections['id']['step'] > 0 ? 0 : $this->_sections['id']['loop']-1;
if ($this->_sections['id']['show']) {
    $this->_sections['id']['total'] = $this->_sections['id']['loop'];
    if ($this->_sections['id']['total'] == 0)
        $this->_sections['id']['show'] = false;
} else
    $this->_sections['id']['total'] = 0;
if ($this->_sections['id']['show']):

            for ($this->_sections['id']['index'] = $this->_sections['id']['start'], $this->_sections['id']['iteration'] = 1;
                 $this->_sections['id']['iteration'] <= $this->_sections['id']['total'];
                 $this->_sections['id']['index'] += $this->_sections['id']['step'], $this->_sections['id']['iteration']++):
$this->_sections['id']['rownum'] = $this->_sections['id']['iteration'];
$this->_sections['id']['index_prev'] = $this->_sections['id']['index'] - $this->_sections['id']['step'];
$this->_sections['id']['index_next'] = $this->_sections['id']['index'] + $this->_sections['id']['step'];
$this->_sections['id']['first']      = ($this->_sections['id']['iteration'] == 1);
$this->_sections['id']['last']       = ($this->_sections['id']['iteration'] == $this->_sections['id']['total']);
?>
                                            <tr>
                                                
                                                <?php if ($this->_tpl_vars['urls'][$this->_sections['id']['index']]['name'] == ''): ?>
                                                <td>N/A</td>
                                                <?php else: ?>
                                                   <td><?php echo ((is_array($_tmp=$this->_tpl_vars['urls'][$this->_sections['id']['index']]['name'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 40, "---") : smarty_modifier_truncate($_tmp, 40, "---")); ?>
</td>
                                                <?php endif; ?>
                                                <td><a href="<?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['url']; ?>
" target="_blank"><?php echo ((is_array($_tmp=$this->_tpl_vars['urls'][$this->_sections['id']['index']]['url'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 40, "---") : smarty_modifier_truncate($_tmp, 40, "---")); ?>
</a></td>
                                                <?php if ($this->_tpl_vars['urls'][$this->_sections['id']['index']]['size'] == '0'): ?>
                                                <td>N/A</td>
                                                <?php else: ?>
                                                   <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['size']; ?>
</td>
                                                <?php endif; ?>
                                                <?php if ($this->_tpl_vars['urls'][$this->_sections['id']['index']]['author'] == ''): ?>
                                                <td>N/A</td>
                                                <?php else: ?>
                                                   <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['author']; ?>
</td>
                                                <?php endif; ?>
                                                <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['date']; ?>
</td>
                                                <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['admin']; ?>
</td>
                                                <td><?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['downloads']; ?>
</td>
                                                <td><a href="<?php echo $this->_tpl_vars['siteurl']; ?>
/<?php echo $this->_tpl_vars['urls'][$this->_sections['id']['index']]['id']; ?>
" target="_blank" >preview</a></td>
                                            </tr>
                                            <?php endfor; endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
			</div>
                        <?php echo $this->_tpl_vars['pagination']; ?>

                        <?php elseif ($this->_tpl_vars['done'] == 0): ?>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
                    <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
                    <div class="panel panel-success">
                        <div class="panel-heading">Enter your search query here</div>
                            <div class="panel-body">
                                <form id="contactForm" action="" method=post>
                                    <div class="row control-group">
                                        <div class="form-group col-xs-8 floating-label-form-group controls">
                                            <input type="hidden" name="form_action" value="1">
                                            <label>search</label>
                                            <input type="text" name="search" class="form-control" placeholder="Search Query" required data-validation-required-message="Please enter a Search Query.">
                                            <p class="help-block text-danger"></p>
                                        </div>
                                    </div>
                                    <br>
                                    <div id="success"></div>
                                    <div class="row">
                                        <div class="form-group col-xs-12">
                                            <button type="submit" class="btn btn-success btn-lg">Send</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                      </div>
                </div>
            </div>
            
             <!-- /.row -->
              
                        <?php endif; ?>
                    </div>
                </div>
                <!-- /.row -->
        </div>
    </section>