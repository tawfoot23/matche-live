<?php /* Smarty version 2.6.19, created on 2015-07-23 22:16:00
         compiled from default/m.html */ ?>
<script>var seconds = <?php echo $this->_tpl_vars['time']; ?>
;</script>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-12" style="text-align: center">
                    <p>
<?php echo $this->_tpl_vars['squar']; ?>
    <?php echo $this->_tpl_vars['squar']; ?>

                    </p>
                    <span id="countdown" style="color:red"></span>
                    <div id="download_link" class="col-lg-8 col-lg-offset-2 text-center" style="display:none;">
<?php if ($this->_tpl_vars['second_page'] == 0): ?>
                                        <?php if ($this->_tpl_vars['link_window'] == '0'): ?>
                                    	<a href="<?php echo $this->_tpl_vars['url']; ?>
" class="btn btn-lg btn-outline" target="_blank">
                                            <i class="fa fa-download"></i> download this file
                                        </a>
                                    <?php else: ?>
                                        <a id="download" href="#" class="btn btn-lg btn-outline" onclick="NewWindow('<?php echo $this->_tpl_vars['url']; ?>
','name','800','600','yes');return false" >
                                            <i class="fa fa-download"></i> download this file
                                        </a>
                                    <?php endif; ?>
<?php else: ?>
                        <a  href="m1.php?id=<?php echo $this->_tpl_vars['rand']; ?>
" class="btn btn-lg btn-outline">
							<i class="fa fa-download"></i> Go to download page
                        </a>
<?php endif; ?>
                    </div>
                   
                    <p style="clear:  both"></p>
                    <p style="margin: 5px">
                    <?php echo $this->_tpl_vars['rectangle']; ?>
  
                    </p>
            </div>
        </div>
    </header>

   