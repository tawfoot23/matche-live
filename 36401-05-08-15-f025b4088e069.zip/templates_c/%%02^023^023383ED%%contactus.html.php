<?php /* Smarty version 2.6.19, created on 2015-07-24 02:37:33
         compiled from default/contactus.html */ ?>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                    <div class="col-lg-12">
                        <div class="WideContentText">
                            <p>Please use the following email address to contact us</p>
                            <h6>Email: <?php echo $this->_tpl_vars['email']; ?>
</h6>
                            <p>
                                Thank you <strong style="font-size: 30px">&#9786;</strong>
                            </p>
                            <br />
                        </div>
                        <div class="WideBottom"></div>
                </div>
                <div class="clear"></div>
            </div>
<!-- END CONTENT -->
        </div>
            </div>
        </div>
    </header>

   