<?php /* Smarty version 2.6.19, created on 2015-07-23 17:10:55
         compiled from default/done.html */ ?>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="row">
            <div class="col-lg-12 text-center">
                    <h2>Your URL was Successfully Created.</h2>
                    <hr class="star-light">
            </div>
</div>
              <div class="col-lg-12">
            <div class="row">
<!-- space 1 ---->	
<div class="col-sm-4 portfolio-item">
			<!--start add link  -->
		<br><div class="login"><!-- ----------------------------e----------------------------------------------------------------------------------------                 -->
				<h4>Short link :</h4> <input type="text" value="<?php echo $this->_tpl_vars['siteurl']; ?>
/m.php?id=<?php echo $this->_tpl_vars['rand']; ?>
" name="user" readonly><br>
				<a href="<?php echo $this->_tpl_vars['siteurl']; ?>
/m.php?id=<?php echo $this->_tpl_vars['rand']; ?>
" target="_blank" style="text-decoration:none"><input type="button" value='Test Your link ' ></a>
				<br><br><p>Simply copy and paste a link below to shorten, and share your new link.</p>
		</div><!--end add link  -->
</div>
<!-- space 2 ----><div class="col-sm-4 portfolio-item">
<script type="text/javascript">
    google_ad_client = "ca-pub-8499374132228990";
    google_ad_slot = "5358900869";
    google_ad_width = 336;
    google_ad_height = 280;
</script>
<!-- shorta -->
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
				
<!-- space 3 ----><div class="col-sm-4 portfolio-item">
<script type="text/javascript">
    google_ad_client = "ca-pub-8499374132228990";
    google_ad_slot = "5358900869";
    google_ad_width = 336;
    google_ad_height = 280;
</script>
<!-- shorta -->
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
</div>
                </div>
            </div>
        </div>
    </header>

    