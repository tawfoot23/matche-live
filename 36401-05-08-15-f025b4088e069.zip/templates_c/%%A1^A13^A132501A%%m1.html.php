<?php /* Smarty version 2.6.19, created on 2015-07-23 17:35:52
         compiled from default/m1.html */ ?>
<script>var seconds = <?php echo $this->_tpl_vars['time']; ?>
;</script>
<?php echo '
<script>
    $(document).ready(function() {
        $(\'#download\').click(function() {
        var linkId= \'www.google.com\';
        $.post( "counter.php", { id: '; ?>
<?php echo $this->_tpl_vars['id']; ?>
<?php echo ' })
        return false;
        }); // end click
    }); // end ready
</script>
'; ?>

<!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p>
                    <script type="text/javascript">
    google_ad_client = "<?php echo $this->_tpl_vars['author']; ?>
";
    google_ad_width = 336;
    google_ad_height = 280;
</script>
<!-- shorta -->
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>     <script type="text/javascript">
    google_ad_client = "<?php echo $this->_tpl_vars['author']; ?>
";
    google_ad_width = 336;
    google_ad_height = 280;
</script>
<!-- shorta -->
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
                    </p>
                    <span id="countdown" style="color:red"></span>
                    <div  id="download_link" style="display:none;"> 
                        <table border="10" width="50%" class="center-block"  style="border: 1px solid white;">
                            <tr>
                                <td >
                                    <div class="col-lg-8 col-lg-offset-2 text-center">
                                    <?php if ($this->_tpl_vars['link_window'] == '0'): ?>
                                    	<center><a href='<?php echo $this->_tpl_vars['url']; ?>
'  style='text-decoration:none'><font color='2C3E50'>Click Here</font></a></center> 
                                    <?php else: ?>
                                     <center><a href='#'  style='text-decoration:none'><font color='2C3E50' onclick="NewWindow('<?php echo $this->_tpl_vars['url']; ?>
','name','800','600','yes');return false">Click Here</font></a></center> 
                                    <?php endif; ?>
                                    </div>
                                </td>      
                            </tr>
                        </table>
                    </div>
                    <br>
                     <p>
                     <script type="text/javascript">
    google_ad_client = "<?php echo $this->_tpl_vars['author']; ?>
";
    google_ad_width = 970;
    google_ad_height = 250;
</script>
<!-- shorta -->
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script> 
                        
                    </p>
             </div>
            </div>
        </div>
    </header>

    