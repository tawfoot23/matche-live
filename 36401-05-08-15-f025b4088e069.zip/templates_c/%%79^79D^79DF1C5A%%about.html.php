<?php /* Smarty version 2.6.19, created on 2015-07-24 02:37:23
         compiled from default/about.html */ ?>
   <!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
<div class="WideContentText">
	<h2><?php echo $this->_tpl_vars['sitename']; ?>
 website's Team</h2>
	<p>The URL shortener service Earn money for Adsense Revenue sharing your shortened links with short link 3jellyhost.pw, Use a URL shortener service.

- Shlinkads allows you to make and Earn money from the links your users post, from the links you place on your website, or from the posts you make in a forum. It is simple and easy to get started making money Today!you can make money with every URL that you shorten and boost your online earning in no Time. Earning money online never been so easy, best rates to our publisher, especially if you can do it when you do your favorite work and browsing the internet. so if you are ready to make some more money sign up today. Share your short urls on facebook, twitter, Forums, personal blog or personal Website, any social networking sites and get earn money.
- Please read our TOS before using this website. We are working hard to keep this simple useful tool for everyone to use.<p>
            We would Like to hear from you if you have any idea for a new 
	tool let us know and we will try our best to make it for you.<p>
	<hr>
	<h6>Email:contact@3jellyhost.pw</h6>
	<hr>
        <p>
            Thank you <strong style="font-size: 30px">&#9786;</strong>
        </p>
</div>
<div class="WideBottom"></div>
</div>
<div class="clear"></div>
</div>
<!-- END CONTENT -->
                </div>
            </div>
        </div>
    </header>

   