<?php

#########################
# protect against xss
########################
function SanitizeString($string) {

    if (get_magic_quotes_gpc()) {
        $string = stripslashes($string);
    }    
    $string = strip_tags($string);
    return htmlentities($string);
}
function check_ref ($domain){
    if (isset($_SERVER['HTTP_REFERER'])){
        $referer = $_SERVER['HTTP_REFERER'];
        if (strpos($referer, $domain) == false) {
            die("it seems not a good request");
        } 
    }   
}
