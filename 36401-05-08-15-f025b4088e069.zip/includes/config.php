<?php
$is_demo = "0";  // 1 for yes and 0 for no
$dbhost  = "mysql.hostinger.ae";
$dbuser  = "u868940522_sh"; // database user name
$dbpass  = "peacemido"; // database password
$dbname  = "u868940522_sh"; // database name
require_once('MysqliDb.php');
$db = new MysqliDb($dbhost, $dbuser, $dbpass, $dbname);