<?php
require 'includes/config.php';
require 'smarty.php';
if($_POST['form_action'] == 1 && isset($_POST['url']) && !empty($_POST['url'])){
    $author = $_POST['author'];
    $name   = $_POST['name'];
    $url    = $_POST['url'];
    $url    = trim($url);
    $size   = $_POST['size'];
    $date   = date("Y-m-d");
    $table  = 'links';  
    // //Sanitize the query array to insert into database
    $data_array['author']   = SanitizeString($db->escape($author));
    $data_array['name']     = SanitizeString($db->escape($name));
    $data_array['url']      = SanitizeString($db->escape($url));
    $data_array['size']     = SanitizeString($db->escape($size));
    $data_array['date']     = SanitizeString($db->escape($date));
    if (!$id = $db->insert($table, $data_array)) {
        echo '<script>alert("we got a problem please try again latter");</script>';
        
    } 
    $rand   =  $id;
    $smarty->assign ("rand", $rand); 
} else {
    header("Location: index.php");
}
$templatefile = 'done';
require 'display.php';