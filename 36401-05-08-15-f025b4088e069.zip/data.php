﻿<?php


class Data {

	var $prefix_char='_';

	var $lang='all';

	var $chars=array();





	function downloadPage($url)

	{

		$h="";

		if(function_exists("curl_init"))

		{

			$c = curl_init();

			curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);

			curl_setopt($c, CURLOPT_URL, $url);

			curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 90);

			curl_setopt($c, CURLOPT_HTTPHEADER,

			array("User-Agent" => $_SERVER["USER_AGENT"],

					  "X-Forwarded-For" => $_SERVER["REMOTE_ADDR"],

					 

			));

			$h = curl_exec ($c);

			curl_close ($c);

		}

		else

		{

			$c = fopen($url, "rb");

			if($c) {

				while(!feof($c))

				$h .= fread($c, 1024);

				fclose($c);

			}

		}

		$h=str_replace("&apos;", "'",$h);

		return $h;

	}





	function LoadCache($file,$time)

	{

		if (!file_exists("data/".$file)) return "";

		if (!(filemtime("data/".$file) + $time > time())) return "";

		$f= gzopen("data/".$file, "r");

		$h="";

		while(!gzeof($f))

		$h.= gzread($f, 1024);

		gzclose($f);

		return $h;

	}



	

	function SaveCache($file,$tekst)

	{

		if (file_exists("data/".$file)&&(!(filemtime("data/".$file) + $time > time()))) return "";

		@unlink("data/".$file);

		$f = gzopen("data/".$file, "w");

		gzputs($f, $tekst);

		gzclose($f);

		return;

	}



	

	function DecodeS($s)

	{

		$c = str_replace($this->prefix_char, " ", $s);

		$c = str_replace('_', " ", $c);

		$c = str_replace('-', " ", $c);

		$c = ucwords($c);

		return $c;

	}



	

	function EncodeS($s)

	{

		$c = ereg_replace("[ -+./\\]", " ", strtolower($s));

		$c = ereg_replace("[^ a-zA-Z0-9_\x80-\xFF]", "", $c);

		foreach($this->chars as $k => $v)

		$c=str_replace($k,$v, $c);

		$c = ereg_replace(" +", " ", $c);

		$c = str_replace("_", ' ', $c);

		$c = str_replace("-", ' ', $c);

		$c = str_replace("  ", ' ', $c);

		$c = str_replace(" ", $this->prefix_char, $c);

		return $c;

	}



	

	function strip_tag($t, $text)

	{

		preg_match("|<$t>(.*?)</$t>|si", $text, $array);

		$t = $array[1];

		if(ereg("^<!\\[CDATA\\[", $t))

		$t = ereg_replace("\\]\\]>$", "",ereg_replace("^<!\\[CDATA\\[", "", $t));

		return $t;

	}



	

	function array_isearch($str, $array) {

		if ((count($array)==0)||($array==null)) return false;

		foreach($array as $k => $v) {

			if(strcasecmp($str, $v) == 0) return $k;

		}

		return false;

	}

	

	function clearCache($check_every, $delete_older_than)

	{

		if (file_exists("data/timer"))

		{

			if (filemtime("data/timer")>time()-$check_every) return;

			@unlink("data/timer");

			fclose(fopen("data/timer","w+"));



			$d = opendir("data");

			while($f = readdir($d))

			{

				if(!ereg("\.gz$", $f)) continue;

				$t = filemtime("data/".$f);

				if($t < time() - $delete_older_than) unlink("data/".$f);

			}

			closedir($d);

		}

		else

		{

			fclose(fopen("data/timer","w+"));

		}

	}



	

	function getMsnResult($query, $first, $count, $download_count,$related_black_words_list, $is_cached, $delete_older_than, $min_cache_size)

	{

		$h=$this->LoadCache('W_'.$this->EncodeS(strtolower($query)).".gz",$delete_older_than);

		$cached=$h!="";

		if ($h=="")	{

			

			$add="";

			if (($this->lang!='')&&($this->lang!='all')) $add='+language%3A'.$this->lang;

            $download_count=50;

			$h=$this->downloadPage("http://www.bing.com/search?q=".urlencode($query).$add."&first=1&count=".$download_count."&FORM=PERE2&format=rss");

			if ($h=="") return array();

		}

		$array=array();

		preg_match_all("|<item>(.*?)</item>|s", $h, $array);

		$result=array();

		$result["max_count_web"]=count($array[1]);

		$result["related"]=array();

		$result["web"]=array();

		$cache="";

		

		if (!$cached) {

			for($i =0; ($i < count($array[1])); $i++)

			{

				$cache.='<item>'.$array[1][$i].'</item>';

				
				$text=strip_tags(trim(strtolower($this->strip_tag("title", $array[1][$i]).' . '.$this->strip_tag("description", $array[1][$i]))));

				

				$text=str_replace(trim(strtolower($query)), "SZUKANYTEKST", $text);

				

				if (!(strpos($text,"SZUKANYTEKST")===false)) {



					$slowa=array();

					$slowo="";

					$break_do_konca=false;

					for($i2=0;$i2<strlen($text);$i2++)

					{

						if (!(strpos("~~~#$%^&*()+=|\/<>{}[]",$text[$i2])===false)) $break_do_konca=true;else

						if (!(strpos('..,;!?',$text[$i2])===false)) {

							

							if ((!$break_do_konca)&&($slowo!="")&&($slowo!="-")&&(strlen($slowo)>1)) $slowa[]=$slowo;

							$slowa[]="";

							$slowo="";

							$break_do_konca=false;

						} else

						if (!(strpos('" 	 ":_-	»'."\n",$text[$i2])===false)) {

							if ((!$break_do_konca)&&($slowo!="")&&($slowo!="-")&&(strlen($slowo)>1)) $slowa[]=$slowo;

							$slowo="";

							$break_do_konca=false;

						} else

						if ($slowo=="SZUKANYTEKST"){

							$slowa[]=$slowo;

							$slowo=$text[$i2];

						} else

						$slowo.=$text[$i2];

					}

					if ((!$break_do_konca)&&($slowo!="")) $slowa[]=$slowo;



					

					for($j=0;$j<count($related_black_words_list);$j++)

					{

						$str=trim(strtolower($related_black_words_list[$j]));

						do {

							$i2=$this->array_isearch($str,$slowa);

							if (!($i2===false)) $slowa[$i2]=null;

						} while(!($i2===false));

					}



					

					$slowa2=array();

					foreach ($slowa as $key => $value) {

						if (!is_null($value))

						$slowa2[]=$value;

					}

					$slowa=$slowa2;

					$slowa2=null;

					
					$slow_dodawanych=1;

					$keyword=trim(strtolower($query));

					if (count($slowa)>0)

					do {

						$i2=$this->array_isearch("SZUKANYTEKST",$slowa);

						if (!($i2===false)) {

							$key_b="";

							$key_f="";

							
							$add=1;

							for($j=$i2-1;($j>=0)&&($j<count($slowa))&&($slowa[$j]!="SZUKANYTEKST")&&($slowa[$j]!="")&&($slowa[$j]!=null);$j--)

							{

								if ($add>$slow_dodawanych) break;

								$key_b=$slowa[$j]." ".$key_b;

								$add++;

							}



							
							$add=1;

							for($j=$i2+1;($j>=0)&&($j<count($slowa))&&($slowa[$j]!="SZUKANYTEKST")&&($slowa[$j]!="")&&($slowa[$j]!=null);$j++)

							{

								if ($add>$slow_dodawanych) break;

								$key_f.=" ".$slowa[$j];

								$add++;

							}

							



							$key_f=str_replace("SZUKANYTEKST", '', $key_f);

							$key_b=str_replace("SZUKANYTEKST", '', $key_b);

							if (($key_f!="")&&( $this->array_isearch($keyword.$key_f,$result["related"])===false)) $result["related"][]=$keyword.$key_f;

							if (($key_b!="")&&( $this->array_isearch($key_b.$keyword,$result["related"])===false)) $result["related"][]=$key_b.$keyword;

							if (($key_f!="")&&($key_b!="")&&( $this->array_isearch($key_b.$keyword.$key_f,$result["related"])===false)) $result["related"][]=$key_b.$keyword.$key_f;

							$slowa[$i2]="";

						}

					} while(!($i2===false));

				}



			}

			if (($is_cached)&&(strlen($cache)>$min_cache_size))	$this->SaveCache('W_'.$this->EncodeS(strtolower($query)).".gz", $cache);



			if ((count($result["related"])>0)&&($is_cached))  {

				$related="";

				foreach ($result["related"] as $key => $value)

				$related.="<item>".$value."</item>";

				$this->SaveCache('R_'.$this->EncodeS(strtolower($query)).".gz", $related);

			}

		}



		//generuje web

		for($i = $first-1; ($i<$first-1+$count)&&($i < count($array[1])); $i++)

		{

			$l = array();

			$l["title"] = $this->strip_tag("title", $array[1][$i]);

			$l["url"] = str_replace("&amp;", "&", $this->strip_tag("link", $array[1][$i]));

			$l["desc"] = $this->strip_tag("description", $array[1][$i]);

			$result["web"][] = $l;

		}

		return $result;

	}



	

	function getAmazonResult($query, $mode, $AWSAccessKeyId, $SubscriptionId, $is_cached, $delete_older_than, $min_cache_size)

	{

		$h=$this->LoadCache('A_'.$mode."_".$this->EncodeS(strtolower($query)).".gz",$delete_older_than);

		$cached=$h!="";

		if ($h=="")	{
		
		$secret_key = 'yBetPR3XdFTzHeKNEkG5tbSDMMWqWbaF8z6EHooV';
			$str_h = "http://ecs.amazonaws.com/onca/xml?Service=AWSECommerceService&Operation=ItemSearch&AWSAccessKeyId="
			.$AWSAccessKeyId."&SubscriptionId=".$SubscriptionId."&AssociateTag=".$SubscriptionId."&Keywords="
			.urlencode($query)."&ResponseGroup=Large&ItemPage=1&SearchIndex=".$mode."&Timestamp=".gmdate('Y-m-d\TH:i:s\Z');

			$url = str_replace("+",urlencode("+"),$str_h);
			$url_a = parse_url($url);
			$url_a['query'] = str_replace(',',urlencode(','),$url_a['query']);
			$url_a['query'] = str_replace(':',urlencode(':'),$url_a['query']);

			$url_s = parse_str($url_a['query'], $params);

			uksort($params, 'strnatcmp');

			$qstr = '';
			foreach ($params as $key => $val) {
				$qstr .= "&".$key."=".rawurlencode($val);
			}
			$qstr = substr($qstr, 1);
			$qstr = str_replace('%20',urlencode('+'),$qstr);
			$qstr = str_replace(',',urlencode(','),$qstr);
			$qstr = str_replace(':',urlencode(':'),$qstr);

			$sig = "GET\n"
			. "ecs.amazonaws.com\n"
			. "/onca/xml\n"
			. $qstr;

			$sig = base64_encode(hash_hmac('sha256', $sig, $secret_key, true));
			$sig = str_replace('+','%2B',$sig);
			$sig = str_replace('=','%3D',$sig);

			$aws = "http://".$url_a['host'].$url_a['path']."?".$qstr."&Signature=".$sig;

			$h=$this->downloadPage($aws);

			if ($h=="") return array();

		}

		if ($is_cached&&!$cached&&(strlen($h)>$min_cache_siz)) $this->SaveCache('A_'.$mode."_".$this->EncodeS(strtolower($query)).".gz", $h);

		$result=array();

		$array=array();

		$res=array();

		preg_match_all("|<Item>(.*?)</Item>|si", $h, $array);

		for($i = 0; $i < count($array[1]) && $i < 10; $i++)

		{

			$l = array();

			$l["title"] = $this->strip_tag("Title", $array[1][$i]);

			$l["url"] = $this->strip_tag("DetailPageURL", $array[1][$i]);

			$l["ourpr"] = $this->strip_tag("FormattedPrice", $array[1][$i]);

			$l["avail"] = $this->strip_tag("Availability", $array[1][$i]);

			$l["img"] = $this->strip_tag("URL", $array[1][$i]);

			if(!$l["img"]) $l["img"] = "http://g-ecx.images-amazon.com/images/G/01/x-site/icons/no-img-sm._V47056216_.gif";

			if($l["ourpr"]) $res[] = $l;

		}

		$result["list"]=$res;

		$result["link"]="http://www.amazon.com/exec/obidos/redirect?link_code=ur2&tag=&camp=1789&creative=9325&path=external-search%3Fsearch-type=ss%26index=" . strtolower($mode) . "%26keyword=" . urlencode($query);

		return $result;

	}



	

	function getEBayResult($query, $pid, $is_cached, $delete_older_than, $min_cache_size)

	{

		$h=$this->LoadCache('E_'.$this->EncodeS(strtolower($query)).".gz",$delete_older_than);

		$cached=$h!="";

		if ($h=="")	{

			$h=$this->downloadPage("http://rss.api.ebay.com/ws/rssapi?FeedName=SearchResults&siteId=0&language=en-US&output=RSS20&catref=C5&sacur=0&from=R6&saobfmts=exsif&fts=2&dfsp=32&afepn=".$pid."&saslc=0&floc=1&sabfmts=0&saaff=afepn&ftrv=1&ftrt=1&fcl=3&frpp=50&satitle=" . urlencode($query) . "&saslop=1&sacat=-1&fss=0");

			if ($h=="") return array();

		}

		if ($is_cached&&!$cached&&(strlen($h)>$min_cache_siz)) $this->SaveCache('E_'.$this->EncodeS(strtolower($query)).".gz", $h);

		$result=array();

		$array=array();

		$res=array();

		preg_match_all("|<item>(.*?)</item>|si", $h, $array);

		$result["link"]= $this->strip_tag("link", $h);

		for($i = 0; $i < count($array[1]) && $i < 10; $i++)

		{

			$l = array();

			$l["title"] = $this->strip_tag("title", $array[1][$i]);

			$l["url"] = str_replace("&amp;", "&", $this->strip_tag("link", $array[1][$i]));

			$l["desc"] = $this->strip_tag("description", $array[1][$i]);

			$res[] = $l;

		}

		$result["list"]=$res;

		return $result;

	}



	

	function getClickBankResult($query, $clickbank, $first, $count, $download_count, $is_cached, $delete_older_than, $min_cache_size)

	{

		$h=$this->LoadCache('C_'.$this->EncodeS(strtolower($query)).".gz", $delete_older_than);

		$cached=$h!="";

		if ($h=="")	$h=$this->downloadPage("http://www.clickbank.com/buy_products.htm?method=Sort&s=1&c=-1&subc=-1&keywords=" . urlencode($query) . "&sortBy=popularity&i=".$download_count);

		if ($is_cached && !$cached && strlen($h)>$min_cache_size)  $this->SaveCache('C_'.$this->EncodeS(strtolower($query)).".gz", $h);

		$result=array();

		$array=array();

		preg_match_all("|<a class=\"siteHeader\"(.*?<br><br>)|s", $h, $array);

		$result["max_count_clickbank"]=count($array[1]);

		$result["links"]=array();



		for($i = $first-1; ($i<$first-1+$count)&&($i < count($array[1])); $i++)

		{

			$l = array();

			$t = $array[1][$i];

			preg_match("|href=\"(.*?)\"|s", $t, $a);

			$l["url"] = str_replace("zzzzz", $clickbank, $a[1]);

			preg_match("|hop.clickbank.net\">(.*?)</a>|s", $t, $a);

			$l["title"] = $a[1];

			preg_match("|</b>(.+)<br><br>|s", $t, $a);

			$l["desc"] = $a[1];

			$result["links"][] = $l;

		}

		return $result;

	}



	

	function getNewsResult($query, $ids, $is_cached, $delete_older_than, $min_cache_size)

	{

		$h=$this->LoadCache('N_'.$this->EncodeS(strtolower($query)).".gz", $delete_older_than);

		$cached=$h!="";

		if ($h=="") $h=$this->downloadPage("http://search.yahooapis.com/NewsSearchService/V1/newsSearch?appid=".urlencode(ids)."&results=20&language=en&query=" . urlencode($query));

		$result=array();

		$array=array();

		

		preg_match_all("|<Result>(.*?)</Result>|s", $h, $array);

		$cache="";

		for($i = 0; $i < count($array[1]); $i++)

		{

			if (!$cached) $cache.="<Result>". $array[1][$i]."</Result>";

			$l = array();

			$l["title"] = $this->strip_tag("Title", $array[1][$i]);

			$l["desc"] = $this->strip_tag("Summary", $array[1][$i]);

			$l["url"] = str_replace("&amp;", "&", $this->strip_tag("Url", $array[1][$i]));

			

			$result[] = $l;

		}

		if ((!$cached)&&($is_cached)&&(strlen($cache)>$min_cache_size)) $this->SaveCache('N_'.$this->EncodeS(strtolower($query)).".gz", $cache);

		return $result;

	}



	

	function getRelated($query, $first, $count, $msn_result, $delete_older_than)

	{

		if (($msn_result==null)||(count($msn_result["related"])==0)||$msn_result["related"]==null||$msn_result=="")

		{

			$h=$this->LoadCache('R_'.$this->EncodeS(strtolower($query)).".gz", $delete_older_than);

			if ($h!="") {

				$array=array();

				$related=array();



				preg_match_all("|<item>(.*?)</item>|s", $h, $array);

				for($i=$first-1;(($i>=0)&&($i<$first-1+$count)&&($i<count($array[1])));$i++)

				{

					$c=array();

					$c["e"]=$this->EncodeS($array[1][$i]);

					$c["d"]=$array[1][$i];

					$related[]=$c;

				}

				return $related;

			}

		}

		if (!(($msn_result==null)||(count($msn_result["related"])==0)))

		{

			$related=array();

			for($i=$first-1;(($i>=0)&&($i<$first-1+$count)&&($i<count($msn_result["related"])));$i++)

			{

				$c=array();

				$c["e"]=$this->EncodeS($msn_result["related"][$i]);

				$c["d"]=$msn_result["related"][$i];

				$related[]=$c;

			}

			return $related;

		}

		return null;

	}



	

	function getYoutubeResult($query, $is_cached, $delete_older_than, $min_cache_size)

	{

		$h=$this->LoadCache('Y_'.$this->EncodeS(strtolower($query)).".gz", $delete_older_than);

		$cached=$h!="";

		if ($h=="") $h=$this->downloadPage("http://www.youtube.com/rss/tag/" . urlencode($query).".rss");

		$result=array();

		$array=array();

		preg_match_all("|<item>(.*?)</item>|s", $h, $array);

		$cache="";

		for($i = 0; $i < count($array[1]); $i++)

		{

			if (!$cached) $cache.="<item>". $array[1][$i]."</item>";

			$l = array();

			$l["title"] = $this->strip_tag("title", $array[1][$i]);



			$z=$array[1][$i];

			$l["url"] = str_replace("&amp;", "&", $this->strip_tag("link", $array[1][$i]));

			preg_match("|<p>(.*?)</p>|si", $z, $a);

			$l["desc"] = $a[1];

			$l["pubDate"] = $this->strip_tag("pubDate", $array[1][$i]);

			preg_match("|<media:thumbnail url=\"(.*?)\"|si", $z, $a);

			$l["img"] = $a[1];

			preg_match("|<media:category label=\"Tags\">(.*?)</media:category>|si", $z, $a);

			$lol=explode(" ",$a[1]);

			$l["tags"]=array();

			for ($i2=0;$i2<count($lol);$i2++)

			{

				$tag=array();

				$tag["e"]=$this->EncodeS($lol[$i2]);

				$tag["d"]=$lol[$i2];

				$l["tags"][]=$tag;

			}



			preg_match("|<enclosure url=\"(.*?)\"|si", $z, $a);

			$l["url_swf"] = $a[1];

			$result[] = $l;

		}

		if ((!$cached)&&($is_cached)&&(strlen($cache)>$min_cache_size)) $this->SaveCache('Y_'.$this->EncodeS(strtolower($query)).".gz", $cache);

		return $result;

	}

}

?>
