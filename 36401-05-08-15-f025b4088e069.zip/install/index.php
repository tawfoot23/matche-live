<!DOCTYPE html>
<html lang="en">
<head>

    <title>Admin Panel</title>
    <!-- Bootstrap Core CSS -->
    <link href="../templates/default/css/bootstrap.css" rel="stylesheet">
    <!-- Custom CSS -->
    <!-- Custom Fonts -->
    <script src="../templates/default/js/bootstrap.min.js"></script>
</head>
<body>
    <div id="wrapper">
<?php

#########################
# created by Sadir Mehdi
########################
// Construct default site path for inserting into the database
$hostname = $_SERVER['HTTP_HOST'];
$app_path = $_SERVER['PHP_SELF'];
// get server protocol
$protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']),'https') === FALSE ? 'http' : 'https';
// Get the parent directory of this (the install) directory
$app_dir_raw = dirname(dirname($app_path));

// Replace backslashes in local root (if we're in a windows environment)
$app_dir = str_replace('\\', '/', $app_dir_raw);	

$url = $protocol . '://' . $hostname . $app_dir;

include '../includes/config.php';
include '../version.php';

$query = "show tables";
$tables = $db->rawQuery($query);
$tables_count =  count($tables); // number of tables if tables are exist
if (($tables_count > 0 ) ) {
    die('
    <div> 
        <div>
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <h3 class="panel-title">Database Error</h3>
                            </div>
                            <div class="panel-body">
                                <p>the datbase is not empty</p>
                                <p>please choose an empty database</p>
                                <p>and try again later</p>
                                <p>if you want to upgrade please click that button</p>
                                <a href="upgrade.php" >
                                <button type="button" class="btn btn-success center-block">Upgrade</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>');
} 
extract($_POST, EXTR_PREFIX_SAME, "wddx"); // make form fileds names as variable names
if (!empty($username) && !empty($password) && !empty($email) && !empty($siteurl)) { 
    // $_POST extracted data
    $username ; 
    $password = sha1($password);
    $email ;
    $siteurl ;
    // end $_POST extracted data
    $today = date("Y-m-d"); // format 2014-12-08
    // creating admin table
    $query = "CREATE TABLE IF NOT EXISTS `admin` (
        `id` int(255) NOT NULL AUTO_INCREMENT,
        `name` varchar(255) NOT NULL DEFAULT '',
        `username` varchar(255) NOT NULL DEFAULT '',
        `password` varchar(255) NOT NULL DEFAULT '',
        `links` tinyint(1) NOT NULL DEFAULT '0',
        `config` tinyint(1) NOT NULL DEFAULT '0',
        `ads` tinyint(1) NOT NULL DEFAULT '0',
        `admins` tinyint(1) NOT NULL DEFAULT '0',
        `email` varchar(255) NOT NULL DEFAULT '',
        `notes` text NOT NULL,
        PRIMARY KEY (`id`)
    )   ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;";
    $db->rawQuery($query);
    // insert records to admin table
    $query = "INSERT INTO `admin` (`id`, `name`, `username`, `password`, `links`, `config`, `ads`, `admins`, `email`, `notes`) 
        VALUES
    (1, 'super admin', '$username', '$password', 1, 1, 1, 1, '$email', 'Write something here to remember');";
    $db->rawQuery($query);
    // creating ads table
    $query = "CREATE TABLE IF NOT EXISTS `ads` (
        `nowdate` date NOT NULL DEFAULT '0000-00-00',
        `id` int(255) NOT NULL AUTO_INCREMENT,
        `name` varchar(255) NOT NULL DEFAULT '',
        `code` text NOT NULL,
        `clicks` int(11) NOT NULL DEFAULT '0',
        `active` varchar(225) NOT NULL,
        `type` varchar(255) NOT NULL DEFAULT '',
        `admin_id` int(255) NOT NULL DEFAULT '0',
        `template` varchar(255) NOT NULL,
        PRIMARY KEY (`id`)
    )   ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;";
    $db->rawQuery($query);
    // insert records to ads table
    $query = "INSERT INTO `ads` (`nowdate`, `id`, `name`, `code`, `clicks`, `active`, `type`, `admin_id`, `template`)
     VALUES
    ('$today', 1, 'rectangle', '', 0, '1', 'squar', 1, 'default'),
    ('$today', 2, 'Leaderboard', '', 0, '1', 'rectangle', 1, 'default');";
    $db->rawQuery($query);
    // creating table config
    $query = "CREATE TABLE IF NOT EXISTS `config` (
        `id` int(255) NOT NULL AUTO_INCREMENT,
        `sitename` varchar(255) NOT NULL DEFAULT '',
        `siteurl` varchar(255) NOT NULL DEFAULT '',
        `sitetitle` varchar(255) NOT NULL DEFAULT '',
        `time` int(255) NOT NULL DEFAULT '0',
        `email` varchar(255) NOT NULL DEFAULT '',
        `schema_version` varchar(10),
        `template` varchar(255) NOT NULL DEFAULT '',
        `keywords` text NOT NULL,
        `description` text NOT NULL,
        `vistis` int(255) NOT NULL DEFAULT '0',
        `sitestate` int(255) NOT NULL DEFAULT '0',
        `sitestatemsg` text NOT NULL,
        `analytics` text,
        PRIMARY KEY (`id`)
    )   ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;";
    $db->rawQuery($query);
    // insert records to table config
    $query = "INSERT INTO `config` (`id`, `sitename`, `siteurl`, `sitetitle`, `time`, `email`, `schema_version`, `template`, `keywords`, `description`, `vistis`, `sitestate`, `sitestatemsg`, `analytics`) 
        VALUES
    (1, 'shorten and protect links', '$siteurl', 'short &amp; protect', 0, '$email',
        '$SCRIPT_SCHEMA_VERSION', 'default', 'short, shorten, tiny url, url shortner, url shrink',
        'Make a long URL short, easy to remember and to share it with friends and others', 0, 1,
    'sorry the website is closed for maintenance ', '<script>\r\n</script>');";
    $db->rawQuery($query);
    // creating table links
    $query = "CREATE TABLE IF NOT EXISTS `links` (
        `id` int(255) NOT NULL AUTO_INCREMENT,
        `url` varchar(255) NOT NULL DEFAULT '',
        `name` varchar(255) NOT NULL DEFAULT '',
        `size` int(255) NOT NULL DEFAULT '0',
        `author` varchar(255) NOT NULL DEFAULT '',
        `admin_id` int(255) NOT NULL DEFAULT '0',
        `downloads` int(255) NOT NULL DEFAULT '0',
        `date` date NOT NULL DEFAULT '0000-00-00',
        PRIMARY KEY (`id`)
    )   ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;";
    $db->rawQuery($query);
    // creating table online
    $query = "CREATE TABLE IF NOT EXISTS `online` (
        `ip` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
        `time` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT ''
    )   ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;";
    $db->rawQuery($query);
    // creating table social
    $query = "CREATE TABLE IF NOT EXISTS `social` (
        `id` int(255) NOT NULL AUTO_INCREMENT,
        `name` varchar(255) NOT NULL DEFAULT '',
        `code` text NOT NULL,
        `active` varchar(225) NOT NULL,
        PRIMARY KEY (`id`)
    )   ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;";
    $db->rawQuery($query);
    // insert records to table social
    $query = "INSERT INTO `social` (`id`, `name`, `code`, `active`) VALUES
        (1, 'facebook', 'https://www.facebook.com/', '1'),
        (2, 'twitter', 'https://twitter.com/', '1'),
        (3, 'google-plus', 'https://plus.google.com', '1'),
        (4, 'dribbble', 'https://dribbble.com', '1'),
        (5, 'linkedin', 'https://www.linkedin.com', '1');";
    $db->rawQuery($query);
    // end schema 1
    
    // start schema 2
    $sql_option = 'CREATE TABLE IF NOT EXISTS `options` (
    `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `option_name` varchar(100) NOT NULL,
    `option_value` int(11) NOT NULL,
    PRIMARY KEY (`option_id`),
    UNIQUE KEY `option_name` (`option_name`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;';
    $db->rawQuery($sql_option);
    $link_window = Array ("option_name" => "link_window",
               "option_value" => "1",
    );
    $id = $db->insert('options', $link_window);
    $second_page = Array ("option_name" => "second_page",
               "option_value" => "1",
    );
    $id = $db->insert('options', $second_page);
   
    echo '
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">    
                                    <div class="panel panel-success">
                                            <div class="panel-heading">installation succeeded
                                            </div>
                                            <div class="panel-body">
                                                    <p>the Installation was successful</p>
                                                    <p>You will be redirected now to the admin panel</p>
                                                    <p>Please wait...</p>
                                            </div>
                                    </div>  
                            </div> 
                    </div> 
            </div>
            <script>
                window.setTimeout(function () {
                location.href = "../admin";
                }, 2000)  
            </script>
    
';
    
    
} else {
    
?>
        
<div class="col-md-4 col-md-offset-5">   
    <h3>Please fill in all the fields</h3>
    <form role="form" method="post">
        <div class="form-group">
          <label for="Name">Username</label>
          <input type="text" class="form-control" name="username" placeholder="Enter username" required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" class="form-control" name="password" id="Password1" placeholder="Password" required>
        </div>
        <div class="form-group">
          <label for="email">email</label>
          <input type="email" class="form-control" name="email" id="email" placeholder="email" required>
        </div>
        <div class="form-group">
            <label for="siteurl">site URL <small>without a backslash "/"</small></label>
          <input type="url" class="form-control" name="siteurl" id="siteurl" value="<?php echo $url ?>" required>
        </div>  
        <button type="submit" class="btn btn-success">Submit</button>
    </form>             
</div>
<?php
}
?>
