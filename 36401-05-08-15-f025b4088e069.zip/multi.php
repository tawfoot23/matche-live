<?php
require 'includes/config.php';
require 'smarty.php';
if (isset($_POST['form_action']) 
        && $_POST['form_action'] == 1 
        && !empty($_POST['multiurls']) 
        && substr($_POST['multiurls'], 0, 4) == 'http') {
    $date   = date('Y-m-d');
    $url    = addslashes($_POST['multiurls']);
    $url    = nl2br($url);
    $sites  = explode("<br />",$url);
    foreach ($sites as $value ) {
        $value  = trim($value);
        $data_array ['url']= SanitizeString($db->escape($value));
        $data_array ['date']= $date;
        if (!$id = $db->insert('links', $data_array)) {
            echo 'we got a problem please try again latter';    
        }
        $links[] = $id;
        $smarty->assign ("links", $links);
        $smarty->assign ("done", 1);
    }
} else {
    $smarty->assign ("done", 0);
}
$templatefile = 'multiadd';
require 'display.php';
