<?php
if (isset($smartyvalues)) {
    foreach ($smartyvalues as $key => $value) {
        $smarty->assign ($key, $value);
    }
}
$header_file = $smarty->fetch ("$template/head.html");
$footer_file = $smarty->fetch ("$template/footer.html");
$body_file   = $smarty->fetch ("$template/$templatefile.html");
$template_output = $header_file . $body_file   . $footer_file;
echo $template_output;